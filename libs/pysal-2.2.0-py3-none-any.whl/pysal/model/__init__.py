import mgwr
import spglm
import spint
import spreg
import spvcm
import tobler
